March-15th-2019
V1.38, by Meinolf
- first release of complete XDF, based on dissassembled and reverse engineered BIN
- includes all parameters except for housekeeping values (SPI/OBD/etc) in 0x4Fxxx-range