-------------------------------------------------------------
-                       MTX Electronics                     -
-    www.mtx-electronics.com / info@mtx-electronics.com     -
-                                                           -
-      TunerPro Checksum Plugin Pack – Free Edition         -
-------------------------------------------------------------

Description:
----------------------------
TunerPro is a free automotive tuning application designed to enable users to edit and refine ECU (Engine Control Unit) maps from virtually any vehicle. Its intuitive interface combined with definition files (XDF) allows tuners to easily locate and visualize map data through comprehensive 2D and 3D charts. TunerPro delivers functionality comparable to, and in some cases surpassing, that of high end commercial software packages making it a popular choice among both enthusiasts and professionals.

One of the key limitations users have historically faced with TunerPro has been the absence of checksum validation and correction capabilities, an essential aspect of successful ECU tuning.

A checksum is a numerical value derived from a block of digital data used to detect errors or alterations. In the context of ECU tuning modifying any part of a binary (BIN) file such as adjusting fuel maps or ignition timing can render the checksum invalid. If the checksum in the modified BIN does not match what the ECU expects the vehicle may fail to start or function correctly.

To address this critical need we have developed a collection of checksum plugins tailored specifically for TunerPro. These plugins automatically detect and correct checksums ensuring your modified files remain valid and safe for use in your vehicle.

Installation Instructions:
----------------------------
Copy all .DLL files included in this plugin pack to your TunerPro plugins directory. This is typically located at Documents\TunerPro Files\Plugins

Automatic Plugin Detection
----------------------------
Upon launching TunerPro, the software will automatically detect all valid plugins located in the Plugins folder. When the appropriate plugin is referenced in your definition file (XDF), checksum correction will be performed automatically each time you save a BIN file.

Adding the Plugin to your XDF
----------------------------
To enable and assign a checksum plugin in TunerPro follow these steps:

Open or create your desired XDF (definition file).

From the top menu, navigate to:
XDF → View/Edit XDF Header Info (Alternatively, press Ctrl + F2)

Click on the "Checksums" tab at the bottom of the header editor window.
Click the "Add New" button to add a new checksum definition.
In the "Plugin Module" dropdown list, select the desired checksum plugin DLL.
In the "Calculator" dropdown menu, choose one of the following options:
- Detect Only: Verifies checksum compatibility upon saving the BIN file but does not modify it.
- Calculate Checksum: Automatically calculates and updates the checksum when saving the BIN file.

SPECIAL NOTES
----------------------------
Some checksum plugins require access to the original (stock) version of the BIN file. To meet this requirement:

Copy the original stock BIN file to the root of your *C:* drive.
Ensure the file is named exactly as specified by the plugin.

C:\Bosch_VAG_TDI_V4.1.BIN
C:\Bosch_EDC15_CR_EURO2.BIN
C:\Bosch_EDC15_CR_EURO3.BIN
C:\Bosch_VAG_ME7_2002.BIN

If the required file is not present in the specified location the plugin will prompt you to create it and will not proceed with checksum calculation until this requirement is met.

Additional Files Needed
----------------------------
If you have issues with the plugins not running you might need the Visual C++ redistribution package available on the MSN site for Microsoft Visual C++ 2017 Redistributable Package (x86)

Support & Feedback
----------------------------
This plugin pack is provided free of charge to support the TunerPro community. For questions, feedback, or to report issues, please contact the developer.

Happy Tuning!